//
//  ViewController2.swift
//  SwiftNews1
//
//  Created by Yuta Fujii on 2018/10/05.
//  Copyright © 2018 Yuta Fujii. All rights reserved.
//

import UIKit
import Firebase
import DTGradientButton


class ViewController2: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    @IBOutlet weak var refleshBtn: UIButton!
    
    @IBOutlet weak var tableView: UITableView!
    
    var posts = [Post]()
    
    var postBox = Post()
    
    var selectedNumber = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()

        tableView.delegate = self
        tableView.dataSource = self
        
        refleshBtn.setGradientBackgroundColors([UIColor(hex: "FF8960"),UIColor(hex: "FF62A5")], direction: .toRight, for: .normal)
        
        refleshBtn.layer.cornerRadius = refleshBtn.frame.height/2
        refleshBtn.layer.masksToBounds = true
        
        // Do any additional setup after loading the view.
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        fetchPosts()
        tableView.reloadData()
        
        
    }

    //セルの数を決定する
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return posts.count
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        
        return 1
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
        
        let titleLabel = cell.viewWithTag(1) as! UILabel
        titleLabel.text = self.posts[indexPath.row].title
        
        return cell
        
    }

    //セルがタッチされたときに呼ばれるメソッド
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        //何番目のセルがタップされたかを取得する
        selectedNumber = indexPath.row
        
        //セルがタップされたときにハイライトを消す
        if let indexPathRow = tableView.indexPathForSelectedRow{
            tableView.deselectRow(at: indexPathRow, animated: true)
        }
        
        //画面遷移を行う
        
        performSegue(withIdentifier: "webView", sender: nil)
        
        
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "webView"{
            
            let webVC:WebViewController = segue.destination as! WebViewController
            webVC.newsURL = self.posts[selectedNumber].newsURL
            
        }
        
    }
    
    //Firebaseからデータを取得する
    func fetchPosts(){
        
        self.posts = [Post]()
        self.postBox = Post()
        
        //参照するデータベースのURLを取得
        let ref = Database.database().reference()
        ref.child("post").queryLimited(toFirst: 10).observeSingleEvent(of: .value) { (snap,error) in
            
            let postsSnap = snap.value as? [String:NSDictionary]
            
            if postsSnap == nil{
                return
            }
            
             self.posts = [Post]()

            
            
            for (_,post) in postsSnap!{
                
                self.postBox = Post()
                if let title = post["title"] as? String,let newsURL = post["newsURL"] as? String{
                    
                    self.postBox.title = title
                    self.postBox.newsURL = newsURL
                    
                }
                
                self.posts.append(self.postBox)
                
            }
        
            self.tableView.reloadData()
            
        }
        
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        return 120
        
    }
    
    @IBAction func reflesh(_ sender: Any) {
    
        fetchPosts()
    
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
