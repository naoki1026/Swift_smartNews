//
//  Post.swift
//  SwiftNews1
//
//  Created by Yuta Fujii on 2018/10/06.
//  Copyright © 2018 Yuta Fujii. All rights reserved.
//

import UIKit

class Post: NSObject {


    var newsURL:String! = String()
    var title:String! = String()
    
    
}
