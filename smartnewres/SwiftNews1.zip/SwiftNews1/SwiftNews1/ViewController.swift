//
//  ViewController.swift
//  SwiftNews1
//
//  Created by Yuta Fujii on 2018/10/05.
//  Copyright © 2018 Yuta Fujii. All rights reserved.
//

import UIKit

class ViewController: AMPagerTabsViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        settings.tabBackgroundColor = UIColor.green
        settings.tabButtonColor = UIColor.green

        tabFont = UIFont.systemFont(ofSize: 17, weight: .bold)
        self.viewControllers = getTabs()
        
    }

    func getTabs() -> [UIViewController]{
        
        let viewController2 = self.storyboard?.instantiateViewController(withIdentifier: "viewController2")

        let viewController3 = self.storyboard?.instantiateViewController(withIdentifier: "viewController3")

        let viewController4 = self.storyboard?.instantiateViewController(withIdentifier: "viewController4")

        viewController2?.title = "本日のトピック"
        viewController3?.title = "エンタメ動画"
        viewController4?.title = "おもしろ"
        
        return [viewController2!,viewController3!,viewController4!]
        
    }
    

}

