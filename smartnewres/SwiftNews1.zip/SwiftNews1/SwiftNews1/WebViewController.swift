//
//  WebViewController.swift
//  SwiftNews1
//
//  Created by Yuta Fujii on 2018/10/05.
//  Copyright © 2018 Yuta Fujii. All rights reserved.
//

import UIKit
import WebKit

class WebViewController: UIViewController,WKNavigationDelegate {

    var newsURL:String! = String()
    
    
    @IBOutlet weak var toolbar: UIToolbar!
    //各種ボタン
    @IBOutlet weak var backBtn: UIBarButtonItem!
    @IBOutlet weak var nextBtn: UIBarButtonItem!
    @IBOutlet weak var refleshBtn: UIBarButtonItem!
    
    var webView:WKWebView!
    
    var indicator:UIActivityIndicatorView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        //WKWebViewを作成
        setWKWebView()
        
        //インディケーターの作成
        setIndicator()
        
        //ボタンの設定
        backBtn.isEnabled = webView.canGoBack
        nextBtn.isEnabled = webView.canGoForward
        
        webView.allowsLinkPreview = true
        
        
        
        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        super.viewWillAppear(animated)
        
        guard let url = URL(string: newsURL) else {
            return
        }
        
        let req = URLRequest(url: url, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: 100)
        self.webView.load(req)
        
    }
    

    func setWKWebView(){
        
        var frame = view.bounds
        
        frame.size.height = frame.height - UIApplication.shared.statusBarFrame.height -
            (navigationController?.navigationBar.frame.height ?? 0) -
            toolbar.frame.height
        
        webView = WKWebView(frame: frame)
        self.view.addSubview(webView)
        webView.navigationDelegate = self
        
        
    }
    
    
    func setIndicator(){
        
        indicator = UIActivityIndicatorView()
        indicator.frame = CGRect(x: 0, y: 0, width: 100, height: 100)
        indicator.center = CGPoint(x: UIScreen.main.bounds.size.width/2, y: UIScreen.main.bounds.size.height/2)
        indicator.hidesWhenStopped = true
        indicator.style = .gray
        
        self.webView.addSubview(indicator)

    }
    
    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        
        decisionHandler(.allow)
        
    }
    
    func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
        
        //インディケーターのスタート
        indicator.startAnimating()
        
    }
    
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        
        //インディケーターストップ
        indicator.stopAnimating()
        
        
    }
    
    
    @IBAction func tapBack(_ sender: Any) {
        
        self.webView.goBack()
        
    }
    
    @IBAction func tapNext(_ sender: Any) {
        
        self.webView.goForward()
        
    }
    
    @IBAction func tapReflesh(_ sender: Any) {

        self.webView.reload()

    }
    
    
    @IBAction func back(_ sender: Any) {
        
        dismiss(animated: true, completion: nil)
        
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
